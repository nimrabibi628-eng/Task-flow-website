import json
from functools import wraps

from django.contrib import messages
from django.contrib.auth import get_user_model, login
from django.contrib.auth.decorators import login_required
from django.db import transaction
from django.db.models import Count, Max, Q
from django.http import JsonResponse
from django.shortcuts import get_object_or_404, redirect, render
from django.utils.dateparse import parse_date
from django.views.decorators.csrf import ensure_csrf_cookie
from django.views.decorators.http import require_POST

from .forms import BoardForm, SignupForm
from .models import Board, BoardList, Card

User = get_user_model()


def accessible(user):
    """Boards the user owns or has been invited to."""
    return Board.objects.filter(Q(owner=user) | Q(members=user)).distinct()


def card_json(c):
    return {"id": c.id, "title": c.title, "description": c.description,
            "due_date": c.due_date.isoformat() if c.due_date else "",
            "label": c.label, "done": c.done}


def members_json(board):
    return [board.owner.username] + [u.username for u in board.members.all()]


# ---------- pages ----------

@login_required
def board_list(request):
    form = BoardForm(request.POST or None)
    if request.method == "POST" and form.is_valid():
        board = form.save(commit=False)
        board.owner = request.user
        board.save()
        for i, title in enumerate(["To Do", "In Progress", "Done"]):
            BoardList.objects.create(board=board, title=title, position=i)
        return redirect("board_detail", pk=board.pk)
    boards = accessible(request.user).select_related("owner").annotate(n_cards=Count("lists__cards", distinct=True))
    return render(request, "boards/board_list.html", {"boards": boards, "form": form})


@login_required
@ensure_csrf_cookie
def board_detail(request, pk):
    board = get_object_or_404(accessible(request.user).select_related("owner"), pk=pk)
    lists = board.lists.prefetch_related("cards")
    payload = {
        "board": {"id": board.id, "title": board.title, "color": board.color,
                  "is_owner": board.owner_id == request.user.id, "members": members_json(board)},
        "lists": [{"id": l.id, "title": l.title, "cards": [card_json(c) for c in l.cards.all()]} for l in lists],
    }
    return render(request, "boards/board_detail.html", {"board": board, "payload": payload})


@login_required
@require_POST
def board_delete(request, pk):
    board = get_object_or_404(Board, pk=pk, owner=request.user)
    board.delete()
    messages.info(request, "Board deleted.")
    return redirect("board_list")


def signup(request):
    if request.user.is_authenticated:
        return redirect("board_list")
    form = SignupForm(request.POST or None)
    if request.method == "POST" and form.is_valid():
        login(request, form.save())
        return redirect("board_list")
    return render(request, "registration/signup.html", {"form": form})


# ---------- JSON API ----------

def api(view):
    @wraps(view)
    def wrapper(request, *args, **kwargs):
        if request.method != "POST":
            return JsonResponse({"error": "POST required"}, status=405)
        if not request.user.is_authenticated:
            return JsonResponse({"error": "Please log in again"}, status=401)
        try:
            data = json.loads(request.body or "{}")
        except ValueError:
            return JsonResponse({"error": "Invalid data"}, status=400)
        return view(request, data, *args, **kwargs)
    return wrapper


def clean_title(data, key="title", limit=200):
    value = str(data.get(key, "")).strip()
    return value[:limit]


def next_position(queryset):
    top = queryset.aggregate(m=Max("position"))["m"]
    return 0 if top is None else top + 1


@api
def list_create(request, data, board_id):
    board = get_object_or_404(accessible(request.user), pk=board_id)
    title = clean_title(data, limit=100)
    if not title:
        return JsonResponse({"error": "Title is required"}, status=400)
    lst = BoardList.objects.create(board=board, title=title, position=next_position(board.lists))
    return JsonResponse({"id": lst.id, "title": lst.title, "cards": []})


@api
def list_rename(request, data, list_id):
    lst = get_object_or_404(BoardList, pk=list_id, board__in=accessible(request.user))
    title = clean_title(data, limit=100)
    if not title:
        return JsonResponse({"error": "Title is required"}, status=400)
    lst.title = title
    lst.save(update_fields=["title"])
    return JsonResponse({"ok": True})


@api
def list_delete(request, data, list_id):
    lst = get_object_or_404(BoardList, pk=list_id, board__in=accessible(request.user))
    lst.delete()
    return JsonResponse({"ok": True})


@api
def card_create(request, data, list_id):
    lst = get_object_or_404(BoardList, pk=list_id, board__in=accessible(request.user))
    title = clean_title(data)
    if not title:
        return JsonResponse({"error": "Title is required"}, status=400)
    card = Card.objects.create(list=lst, title=title, position=next_position(lst.cards))
    return JsonResponse(card_json(card))


@api
def card_update(request, data, card_id):
    card = get_object_or_404(Card, pk=card_id, list__board__in=accessible(request.user))
    if "title" in data:
        title = clean_title(data)
        if not title:
            return JsonResponse({"error": "Title is required"}, status=400)
        card.title = title
    if "description" in data:
        card.description = str(data["description"])[:5000]
    if "due_date" in data:
        raw = data["due_date"]
        card.due_date = parse_date(raw) if raw else None
    if "label" in data:
        if data["label"] not in dict(Card.LABELS):
            return JsonResponse({"error": "Invalid label"}, status=400)
        card.label = data["label"]
    if "done" in data:
        card.done = bool(data["done"])
    card.save()
    return JsonResponse(card_json(card))


@api
def card_delete(request, data, card_id):
    card = get_object_or_404(Card, pk=card_id, list__board__in=accessible(request.user))
    card.delete()
    return JsonResponse({"ok": True})


@api
def card_move(request, data, card_id):
    card = get_object_or_404(Card, pk=card_id, list__board__in=accessible(request.user))
    dest = get_object_or_404(BoardList, pk=data.get("list_id"), board=card.list.board)
    try:
        position = int(data.get("position", 0))
    except (TypeError, ValueError):
        position = 0
    with transaction.atomic():
        old = card.list
        ids = list(dest.cards.exclude(pk=card.pk).values_list("id", flat=True))
        position = max(0, min(position, len(ids)))
        ids.insert(position, card.id)
        card.list = dest
        card.save(update_fields=["list"])
        for i, cid in enumerate(ids):
            Card.objects.filter(pk=cid).update(position=i)
        if old.pk != dest.pk:
            for i, cid in enumerate(old.cards.values_list("id", flat=True)):
                Card.objects.filter(pk=cid).update(position=i)
    return JsonResponse({"ok": True})


@api
def member_add(request, data, board_id):
    board = get_object_or_404(Board, pk=board_id, owner=request.user)
    username = str(data.get("username", "")).strip()
    user = User.objects.filter(username__iexact=username).first()
    if not user:
        return JsonResponse({"error": f"No user named “{username}”"}, status=404)
    if user.pk != board.owner_id:
        board.members.add(user)
    return JsonResponse({"members": members_json(board)})
