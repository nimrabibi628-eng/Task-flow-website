from django import forms
from django.contrib.auth.forms import AuthenticationForm, UserCreationForm

from .models import Board


class BootstrapMixin:
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        for field in self.fields.values():
            cls = "form-select" if isinstance(field.widget, forms.Select) else "form-control"
            field.widget.attrs.setdefault("class", cls)


class LoginForm(BootstrapMixin, AuthenticationForm):
    pass


class SignupForm(BootstrapMixin, UserCreationForm):
    pass


class BoardForm(BootstrapMixin, forms.ModelForm):
    class Meta:
        model = Board
        fields = ["title", "color"]
        widgets = {"title": forms.TextInput(attrs={"placeholder": "Board title"})}
