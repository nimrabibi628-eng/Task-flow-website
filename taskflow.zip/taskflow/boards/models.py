from django.conf import settings
from django.db import models


class Board(models.Model):
    COLORS = [("blue", "Blue"), ("green", "Green"), ("purple", "Purple"),
              ("orange", "Orange"), ("red", "Red"), ("dark", "Dark")]
    owner = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name="boards")
    members = models.ManyToManyField(settings.AUTH_USER_MODEL, blank=True, related_name="shared_boards")
    title = models.CharField(max_length=100)
    color = models.CharField(max_length=10, choices=COLORS, default="blue")
    created = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ["-created"]

    def __str__(self):
        return self.title


class BoardList(models.Model):
    board = models.ForeignKey(Board, on_delete=models.CASCADE, related_name="lists")
    title = models.CharField(max_length=100)
    position = models.PositiveIntegerField(default=0)

    class Meta:
        ordering = ["position", "id"]

    def __str__(self):
        return f"{self.board} / {self.title}"


class Card(models.Model):
    LABELS = [("", "None"), ("red", "Red"), ("orange", "Orange"), ("green", "Green"),
              ("blue", "Blue"), ("purple", "Purple")]
    list = models.ForeignKey(BoardList, on_delete=models.CASCADE, related_name="cards")
    title = models.CharField(max_length=200)
    description = models.TextField(blank=True)
    due_date = models.DateField(null=True, blank=True)
    label = models.CharField(max_length=10, choices=LABELS, blank=True, default="")
    done = models.BooleanField(default=False)
    position = models.PositiveIntegerField(default=0)
    created = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ["position", "id"]

    def __str__(self):
        return self.title
