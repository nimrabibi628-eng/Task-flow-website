from django.contrib import admin

from .models import Board, BoardList, Card


@admin.register(Board)
class BoardAdmin(admin.ModelAdmin):
    list_display = ("title", "owner", "color", "created")
    filter_horizontal = ("members",)


admin.site.register(BoardList)


@admin.register(Card)
class CardAdmin(admin.ModelAdmin):
    list_display = ("title", "list", "due_date", "label", "done")
    list_filter = ("done", "label")
