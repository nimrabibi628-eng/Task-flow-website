from django.contrib.auth import views as auth_views
from django.urls import path

from . import views
from .forms import LoginForm

urlpatterns = [
    path("", views.board_list, name="board_list"),
    path("board/<int:pk>/", views.board_detail, name="board_detail"),
    path("board/<int:pk>/delete/", views.board_delete, name="board_delete"),
    path("accounts/signup/", views.signup, name="signup"),
    path("accounts/login/", auth_views.LoginView.as_view(authentication_form=LoginForm), name="login"),
    path("accounts/logout/", auth_views.LogoutView.as_view(), name="logout"),

    # JSON API used by static/js/board.js
    path("api/boards/<int:board_id>/lists/", views.list_create),
    path("api/boards/<int:board_id>/members/", views.member_add),
    path("api/lists/<int:list_id>/rename/", views.list_rename),
    path("api/lists/<int:list_id>/delete/", views.list_delete),
    path("api/lists/<int:list_id>/cards/", views.card_create),
    path("api/cards/<int:card_id>/update/", views.card_update),
    path("api/cards/<int:card_id>/delete/", views.card_delete),
    path("api/cards/<int:card_id>/move/", views.card_move),
]
