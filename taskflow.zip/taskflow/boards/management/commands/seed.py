from datetime import date, timedelta

from django.contrib.auth import get_user_model
from django.core.management.base import BaseCommand

from boards.models import Board, BoardList, Card


class Command(BaseCommand):
    help = "Create a demo user and a sample board"

    def handle(self, *args, **options):
        User = get_user_model()
        user, created = User.objects.get_or_create(username="demo")
        if created:
            user.set_password("demo12345")
            user.save()
        if Board.objects.filter(owner=user).exists():
            self.stdout.write("Demo board already exists.")
            return
        board = Board.objects.create(owner=user, title="Semester Plan", color="blue")
        today = date.today()
        data = {
            "To Do": [("Finish web development project", "red", 3), ("Prepare HCI presentation", "orange", 6), ("Read OS chapter 5", "", None)],
            "In Progress": [("Build portfolio website", "purple", 10), ("Computer graphics assignment", "blue", 5)],
            "Done": [("Submit architecture lab report", "green", None)],
        }
        for i, (title, cards) in enumerate(data.items()):
            lst = BoardList.objects.create(board=board, title=title, position=i)
            for j, (ct, label, days) in enumerate(cards):
                Card.objects.create(list=lst, title=ct, label=label, position=j, done=(title == "Done"),
                                    due_date=today + timedelta(days=days) if days else None)
        self.stdout.write(self.style.SUCCESS("Created demo board. Login: demo / demo12345"))
