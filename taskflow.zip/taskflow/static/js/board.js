(function () {
  "use strict";

  var state = JSON.parse(document.getElementById("board-data").textContent);
  var LABELS = { red: "#ef4444", orange: "#f97316", green: "#22c55e", blue: "#3b82f6", purple: "#8b5cf6" };
  var query = "";
  var openAddFor = null;
  var currentCardId = null;
  var line = null;

  function $(sel) { return document.querySelector(sel); }
  function el(tag, cls, text) {
    var e = document.createElement(tag);
    if (cls) e.className = cls;
    if (text !== undefined) e.textContent = text;
    return e;
  }
  function cookie(name) {
    var m = document.cookie.match(new RegExp("(?:^|; )" + name + "=([^;]*)"));
    return m ? decodeURIComponent(m[1]) : "";
  }
  function toast(msg, kind) {
    var t = $("#toast");
    t.className = "toast text-bg-" + (kind || "dark");
    $("#toast-body").textContent = msg;
    bootstrap.Toast.getOrCreateInstance(t, { delay: 2500 }).show();
  }
  function api(path, data) {
    return fetch("/api" + path, {
      method: "POST",
      headers: { "Content-Type": "application/json", "X-CSRFToken": cookie("csrftoken") },
      body: JSON.stringify(data || {}),
    }).then(function (res) {
      return res.json().catch(function () { return {}; }).then(function (json) {
        if (!res.ok) {
          toast(json.error || "Something went wrong", "danger");
          throw new Error(json.error || res.status);
        }
        return json;
      });
    });
  }
  function today() {
    var d = new Date();
    return d.getFullYear() + "-" + String(d.getMonth() + 1).padStart(2, "0") + "-" + String(d.getDate()).padStart(2, "0");
  }
  function fmtDate(iso) {
    var p = iso.split("-");
    return new Date(+p[0], +p[1] - 1, +p[2]).toLocaleDateString(undefined, { day: "numeric", month: "short" });
  }
  function findCard(id) {
    for (var i = 0; i < state.lists.length; i++) {
      var l = state.lists[i];
      for (var j = 0; j < l.cards.length; j++) {
        if (l.cards[j].id === id) return { list: l, card: l.cards[j], index: j };
      }
    }
    return null;
  }
  function matches(c) {
    if (!query) return true;
    return c.title.toLowerCase().indexOf(query) !== -1 || c.description.toLowerCase().indexOf(query) !== -1;
  }

  // ---------- drag and drop ----------
  function dropIndex(body, y) {
    var cards = Array.prototype.slice.call(body.querySelectorAll(".kcard:not(.dragging)"));
    for (var i = 0; i < cards.length; i++) {
      var r = cards[i].getBoundingClientRect();
      if (y < r.top + r.height / 2) return i;
    }
    return cards.length;
  }
  function showLine(body, y) {
    if (!line) line = el("div", "drop-line");
    var cards = Array.prototype.slice.call(body.querySelectorAll(".kcard:not(.dragging)"));
    var i = dropIndex(body, y);
    if (cards[i]) body.insertBefore(line, cards[i]); else body.appendChild(line);
  }
  function clearLine() {
    if (line && line.parentNode) line.parentNode.removeChild(line);
  }
  function moveCard(cardId, listId, index) {
    var f = findCard(cardId);
    var dest = state.lists.filter(function (l) { return l.id === listId; })[0];
    if (!f || !dest) return;
    f.list.cards.splice(f.index, 1);
    if (query) index = dest.cards.length;
    index = Math.max(0, Math.min(index, dest.cards.length));
    dest.cards.splice(index, 0, f.card);
    render();
    api("/cards/" + cardId + "/move/", { list_id: listId, position: index }).catch(function () { location.reload(); });
  }

  // ---------- rendering ----------
  function cardEl(c) {
    var d = el("div", "kcard" + (c.done ? " done" : ""));
    d.draggable = true;
    d.addEventListener("dragstart", function (e) {
      e.dataTransfer.setData("text/plain", String(c.id));
      e.dataTransfer.effectAllowed = "move";
      setTimeout(function () { d.classList.add("dragging"); }, 0);
    });
    d.addEventListener("dragend", function () { d.classList.remove("dragging"); clearLine(); });
    d.addEventListener("click", function () { openCard(c.id); });

    if (c.label) {
      var bar = el("div", "klabel");
      bar.style.background = LABELS[c.label];
      d.appendChild(bar);
    }
    d.appendChild(el("div", "ktitle", c.title));
    var meta = el("div", "kmeta");
    if (c.due_date) {
      var late = !c.done && c.due_date < today();
      meta.appendChild(el("span", "badge " + (late ? "text-bg-danger" : "text-bg-secondary"), "📅 " + fmtDate(c.due_date)));
    }
    if (c.description) meta.appendChild(el("span", "badge text-bg-light border", "📝"));
    if (c.done) meta.appendChild(el("span", "badge text-bg-success", "✔ Done"));
    if (meta.childNodes.length) d.appendChild(meta);
    return d;
  }

  function addCardForm(l) {
    var wrap = el("div", "mt-2");
    var btn = el("button", "btn btn-sm btn-light w-100 text-start", "+ Add a card");
    var form = el("form", "d-none");
    var ta = el("textarea", "form-control form-control-sm mb-1");
    ta.rows = 2;
    ta.placeholder = "Card title…";
    var ok = el("button", "btn btn-sm btn-primary me-1", "Add");
    ok.type = "submit";
    var cancel = el("button", "btn btn-sm btn-outline-secondary", "Cancel");
    cancel.type = "button";
    form.appendChild(ta); form.appendChild(ok); form.appendChild(cancel);
    wrap.appendChild(btn); wrap.appendChild(form);

    function show() { btn.classList.add("d-none"); form.classList.remove("d-none"); ta.focus(); }
    btn.addEventListener("click", function () { openAddFor = l.id; show(); });
    cancel.addEventListener("click", function () {
      openAddFor = null; form.classList.add("d-none"); btn.classList.remove("d-none"); ta.value = "";
    });
    ta.addEventListener("keydown", function (e) {
      if (e.key === "Enter" && !e.shiftKey) { e.preventDefault(); form.requestSubmit(); }
    });
    form.addEventListener("submit", function (e) {
      e.preventDefault();
      var t = ta.value.trim();
      if (!t) return;
      api("/lists/" + l.id + "/cards/", { title: t }).then(function (card) {
        l.cards.push(card);
        openAddFor = l.id;
        render();
      });
    });
    if (openAddFor === l.id) setTimeout(show, 0);
    return wrap;
  }

  function listEl(l) {
    var box = el("div", "klist");
    var head = el("div", "klist-head");
    var title = el("input", "form-control form-control-sm klist-title");
    title.value = l.title;
    title.maxLength = 100;
    title.addEventListener("change", function () {
      var v = title.value.trim();
      if (!v) { title.value = l.title; return; }
      api("/lists/" + l.id + "/rename/", { title: v }).then(function () { l.title = v; });
    });
    var count = el("span", "badge text-bg-light", String(l.cards.length));
    var del = el("button", "btn btn-sm btn-link text-danger p-0 px-1", "✕");
    del.title = "Delete list";
    del.addEventListener("click", function () {
      if (!confirm("Delete “" + l.title + "” and all its cards?")) return;
      api("/lists/" + l.id + "/delete/").then(function () {
        state.lists = state.lists.filter(function (x) { return x.id !== l.id; });
        render();
      });
    });
    head.appendChild(title); head.appendChild(count); head.appendChild(del);

    var body = el("div", "klist-body");
    l.cards.filter(matches).forEach(function (c) { body.appendChild(cardEl(c)); });
    body.addEventListener("dragover", function (e) {
      e.preventDefault();
      body.classList.add("over");
      showLine(body, e.clientY);
    });
    body.addEventListener("dragleave", function (e) {
      if (!body.contains(e.relatedTarget)) { body.classList.remove("over"); clearLine(); }
    });
    body.addEventListener("drop", function (e) {
      e.preventDefault();
      body.classList.remove("over");
      var idx = dropIndex(body, e.clientY);
      clearLine();
      var id = parseInt(e.dataTransfer.getData("text/plain"), 10);
      if (id) moveCard(id, l.id, idx);
    });

    box.appendChild(head); box.appendChild(body); box.appendChild(addCardForm(l));
    return box;
  }

  function newListEl() {
    var box = el("div", "klist-new");
    var form = el("form");
    var input = el("input", "form-control form-control-sm mb-1");
    input.placeholder = "+ Add another list";
    input.maxLength = 100;
    var ok = el("button", "btn btn-sm btn-primary", "Add list");
    ok.type = "submit";
    form.appendChild(input); form.appendChild(ok);
    form.addEventListener("submit", function (e) {
      e.preventDefault();
      var t = input.value.trim();
      if (!t) return;
      api("/boards/" + state.board.id + "/lists/", { title: t }).then(function (l) {
        state.lists.push(l);
        render();
      });
    });
    box.appendChild(form);
    return box;
  }

  function renderStats() {
    var total = 0, done = 0, late = 0, t = today();
    state.lists.forEach(function (l) {
      l.cards.forEach(function (c) {
        total++;
        if (c.done) done++;
        else if (c.due_date && c.due_date < t) late++;
      });
    });
    $("#stats").textContent = total + " cards · " + done + " done" + (late ? " · " + late + " overdue" : "");
  }

  function renderMembers() {
    var box = $("#members");
    box.innerHTML = "";
    state.board.members.forEach(function (name) {
      var a = el("div", "avatar-sm", name.charAt(0).toUpperCase());
      a.title = name;
      box.appendChild(a);
    });
  }

  function render() {
    var wrap = $("#lists");
    wrap.innerHTML = "";
    state.lists.forEach(function (l) { wrap.appendChild(listEl(l)); });
    wrap.appendChild(newListEl());
    renderStats();
  }

  // ---------- card modal ----------
  var cardModal = new bootstrap.Modal($("#cardModal"));

  function openCard(id) {
    var f = findCard(id);
    if (!f) return;
    currentCardId = id;
    $("#m-title").value = f.card.title;
    $("#m-desc").value = f.card.description;
    $("#m-due").value = f.card.due_date;
    $("#m-label").value = f.card.label;
    $("#m-done").checked = f.card.done;
    var sel = $("#m-list");
    sel.innerHTML = "";
    state.lists.forEach(function (l) {
      var o = el("option", "", l.title);
      o.value = l.id;
      if (l.id === f.list.id) o.selected = true;
      sel.appendChild(o);
    });
    cardModal.show();
  }

  $("#m-save").addEventListener("click", function () {
    var f = findCard(currentCardId);
    if (!f) return;
    var title = $("#m-title").value.trim();
    if (!title) { toast("Title is required", "danger"); return; }
    api("/cards/" + currentCardId + "/update/", {
      title: title,
      description: $("#m-desc").value,
      due_date: $("#m-due").value,
      label: $("#m-label").value,
      done: $("#m-done").checked,
    }).then(function (updated) {
      Object.assign(f.card, updated);
      var target = parseInt($("#m-list").value, 10);
      cardModal.hide();
      if (target !== f.list.id) {
        var dest = state.lists.filter(function (l) { return l.id === target; })[0];
        moveCard(currentCardId, target, dest.cards.length);
      } else {
        render();
      }
    });
  });

  $("#m-delete").addEventListener("click", function () {
    if (!confirm("Delete this card?")) return;
    var f = findCard(currentCardId);
    api("/cards/" + currentCardId + "/delete/").then(function () {
      f.list.cards.splice(f.index, 1);
      cardModal.hide();
      render();
    });
  });

  // ---------- search and sharing ----------
  $("#search").addEventListener("input", function (e) {
    query = e.target.value.trim().toLowerCase();
    render();
  });

  if (state.board.is_owner) $("#share-btn").classList.remove("d-none");
  $("#share-add").addEventListener("click", function () {
    var name = $("#share-user").value.trim();
    if (!name) return;
    api("/boards/" + state.board.id + "/members/", { username: name }).then(function (res) {
      state.board.members = res.members;
      $("#share-user").value = "";
      renderMembers();
      toast("Board shared with " + name, "success");
    });
  });

  renderMembers();
  render();
})();
