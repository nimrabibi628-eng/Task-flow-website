# TaskFlow – Django Web Application (Trello style Kanban board)

```
python -m venv venv
venv\Scripts\activate          # Mac/Linux: source venv/bin/activate
pip install -r requirements.txt
python manage.py makemigrations boards
python manage.py migrate
python manage.py seed          # demo board (login: demo / demo12345)
python manage.py runserver
```

Open http://127.0.0.1:8000/

What makes it a web *application*: the board page is a single-page interface. Cards and lists are
created, edited, moved and deleted without reloading the page. JavaScript (static/js/board.js) talks to
a JSON API in boards/views.py using fetch().

Features: boards, lists, cards, drag and drop (saved in the database), card details (description, due date,
colour label, done), overdue warnings, search, sharing a board with another user, signup/login.
On phones where drag and drop is not available, open a card and use the "List" dropdown to move it.
